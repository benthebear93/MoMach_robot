#include <stdlib.h>
#include <stdio.h>
#include <WinSock2.h>
#include <iostream>
#include <string>
#include "tcpip_basic.h"
#include <sstream>
using namespace std;

char * set_s_buff(char * s_buff, unsigned char add1, unsigned char add2 ){
	for (int i = 0; i < 5; i++) s_buff[i] = 0x00; //MBAP
	unsigned char len = 0x06; //length
	unsigned char unit_id = 0x01; //unit id
	unsigned char func = reg_read;//function code
	unsigned char read_len = add1; //0x35;//length
	unsigned char read_len2 = add2; //0x68; //length
	unsigned char data = 0x00; //read
	unsigned char data2 = 0x01; //len
	s_buff[5] = len;
	s_buff[6] = unit_id;
	s_buff[7] = func;
	s_buff[8] = read_len;
	s_buff[9] = read_len2;
	s_buff[10] = data;
	s_buff[11] = data2;
	return s_buff;
}

void PrintHexa(char* buff, size_t len, int type) { 
	size_t i; 
	if (type == bit_type) {
		printf("bit type receive : ");
		for (i = 0; i < len; i++)
		{
			printf("%02X ", (unsigned char)buff[i]);
		}
		printf(" recive");
		printf("\n");
	}
	else if(type == reg_type){
		printf("reg type receive : ");
		for (i = 0; i < len; i++)
		{
			printf("%02X ", (unsigned char)buff[i]);
		}
		printf(" recive");
		printf("\n");
	}
	else {
		printf("send             : ");
		for (i = 0; i < len; i++)
		{
			printf("%02X ", (unsigned char)buff[i]);
		}
		printf(" send");
		printf("\n");
	}
}

int check_data(char *buff) {
	int num1 = 0, num2 = 0, num3 = 0;
	//printf("%02X      %02X \n", (unsigned char)buff[9], (unsigned char)buff[10]);
	num1 = (unsigned char)buff[9];
	num2 = (unsigned char)buff[10];
	num3 = (num1 << 8) | (num2);
	return num3;
}

int * Current_Pos(int x, int temp_x, int y, int temp_y) {
	int update_x = (temp_x - x) / 524;
	int update_y = (temp_y - y) / 524;
	if (temp_x - x < 0) update_x = -1 * update_x;
	else update_x = 1 * update_x;

	if (temp_y - y < 0) update_y = -1 * update_y;
	else update_y = 1 * update_y;
	int curr_x_y[2] = { update_x, update_y };
	return curr_x_y;

}