#include "tcpip_basic.h"

void main()
{
	SOCKET sock; WSADATA wsa;
	char s_x_buff[12]; //send x req
	char s_y_buff[12]; //send y req
	char b_x_buff[11]; //bit read
	char r_x_buff[13]; // register read
	char b_y_buff[11];
	char r_y_buff[13];
	struct sockaddr_in sock_addr;
	int ret = 0;
	WSAStartup(MAKEWORD(2, 2), &wsa);
	sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
	memset(&sock_addr, 0, sizeof(sock_addr));
	sock_addr.sin_family = AF_INET;
	sock_addr.sin_addr.s_addr = inet_addr(DELTA_IP);
	sock_addr.sin_port = htons(DELTA_PORT);

	if (connect(sock, (struct sockaddr*)&sock_addr, sizeof(sock_addr)) == SOCKET_ERROR) {
		perror("connect()");
		closesocket(sock);
		WSACleanup();
		return;
	}
	else {
		printf("connected\n");
	}
	memset(s_x_buff, 0, 12); //send buff set
	while (1) {
		//memset(b_x_buff, 0, 11); //bit buff set
		//memset(r_x_buff, 0, 11); //reg buff set

		*s_x_buff = *set_s_buff(s_x_buff, x_add1, x_add2);
		*s_y_buff = *set_s_buff(s_y_buff, y_add1, y_add2);
		//PrintHexa(s_x_buff, 12, 0);
		send(sock, s_x_buff, 12, 0);
		if (send(sock, s_x_buff, 12, 0) == SOCKET_ERROR) {
			perror("send()");
			closesocket(sock);
			WSACleanup();
			return;
		}
		if (s_x_buff[7] == b_read) {
			ret = recv(sock, b_x_buff, 11, 0);
			//PrintHexa(b_x_buff, ret, bit_type);
			printf("length : %d\n", ret);
		}
		else {
			ret = recv(sock, r_x_buff, 11, 0);
			//PrintHexa(r_x_buff, ret, reg_type);
			printf("length : %d \n", ret);

		}
		if (ret == SOCKET_ERROR) {
			perror("recv()"); closesocket(sock); WSACleanup();
			return;
		}

		int x_encoder = check_data(r_x_buff);
		printf("current motor data : %d\n", x_encoder);

		//PrintHexa(s_y_buff, 12, 0);
		send(sock, s_y_buff, 12, 0);

		if (send(sock, s_y_buff, 12, 0) == SOCKET_ERROR) {
			perror("send()");
			closesocket(sock);
			WSACleanup();
			return;
		}
		if (s_y_buff[7] == b_read) {
			ret = recv(sock, b_y_buff, 11, 0);
			//PrintHexa(b_y_buff, ret, bit_type);
			printf("length : %d\n", ret);
		}
		else {
			ret = recv(sock, r_y_buff, 11, 0);
			//PrintHexa(r_y_buff, ret, reg_type);
			printf("length : %d \n", ret);

		}
		if (ret == SOCKET_ERROR) {
			perror("recv()"); closesocket(sock); WSACleanup();
			return;
		}

		int y_encoder = check_data(r_x_buff);
		printf("current motor data : %d\n", y_encoder);

		//PrintHexa(s_y_buff, 12, 0);
		int pos_x_y[2] = { 0, 0 };
		int temp_x = x_encoder;
		int temp_y = y_encoder;
		* pos_x_y = *Current_Pos(x_encoder,  temp_x, y_encoder, temp_y);
		temp_x = 0;
		temp_y = 0;
	}

	closesocket(sock);
	WSACleanup();
	system("pause");
}